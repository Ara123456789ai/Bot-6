#!/usr/bin/env python3
"""
Robust re-run of the event study (stage 6). Same events and horizons as event_study.py, but built to survive a few huge moves:

  1. DATA CHECK     the largest 30-minute and 240-minute moves with dates, and the size of typical moves per year.
  2. ROBUST CELLS   for every cell: raw mean, MEDIAN, WINSORISED mean (every price change capped at its 1st/99th percentile, for the
                    events and for random timing alike), the t of the winsorised mean, a z against random-week timing that is
                    divided by the overall spread of all z scores (calibrated), the winsorised mean in 2024, 2025 and 2026 separately,
                    and the raw mean with the 5 biggest moves dropped.
  3. THE CANDIDATES the cells we discussed, side by side.
  4. STRICT RULE    a cell passes only if ALL hold: 30+ events; winsorised |t| above the Bonferroni limit for the number of cells;
                    the median points the same way; every year with 8+ events points the same way as the winsorised mean.
Run: python3 event_robust.py --prices download/brentcmdusd-m1-bid-2024-01-01-2026-11-10.csv > robust_report.txt
"""
import argparse, csv, os, statistics, sys, time
from datetime import datetime, timezone
from statistics import NormalDist

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import backtest as B
import entry_tests as T
import event_study as S

MIN, DAY = B.MIN, B.DAY

CANDIDATES = [
    ("Pluto aspect + amber + S below -0.15", 60), ("Pluto Ascendant aspect, any angle", 60),
    ("Pluto Ascendant aspect at 45 deg", 30), ("Pluto Ascendant aspect at 45 deg", 60),
    ("Moon-Pluto hard angles (0/45/90/135/150/180), exact", 240), ("Moon-Pluto at 135 deg, exact", 240),
    ("Moon-Pluto at 90 deg, exact", 240), ("Moon-Pluto soft angles (30/60/72/120/144), exact", -240),
    ("Moon-Pluto soft angles (30/60/72/120/144), exact", 60), ("Moon-Pluto all angles, exact", -240),
    ("Moon-Saturn soft angles (30/60/72/120/144), onset", 240), ("Moon-Saturn at 72 deg, onset", 240),
    ("Moon-Saturn at 150 deg, onset", 240), ("Moon-Saturn at 60 deg, onset", 30),
    ("Moon-Pluto at 60 deg, onset", 240), ("Moon-Pluto at 72 deg, exact", -240),
]


def rob(raw, win, events, h, shifts):
    """Robust statistics for one cell. raw / win are Px objects without / with winsorising."""
    ks_r, rs_r = S.sample(raw, events, h)
    ks_w, rs_w = S.sample(win, events, h)
    n = len(rs_w)
    if n < 5:
        return None
    sd = statistics.pstdev(rs_w)
    m_w = statistics.mean(rs_w)
    t_w = m_w / (sd / n ** 0.5) if sd > 0 else 0.0
    mu, nsd = S.null_stats(win, events, h, shifts)
    z_w = (m_w - mu) / nsd if nsd else 0.0
    m_raw = statistics.mean(rs_r)
    sd_raw = statistics.pstdev(rs_r)
    t_raw = m_raw / (sd_raw / n ** 0.5) if sd_raw > 0 else 0.0
    med = statistics.median([x + raw.base[h] - raw.bmed[h] for x in rs_r])
    big = sorted(range(len(rs_r)), key=lambda i: -abs(rs_r[i]))[:5]
    rest = [x for i, x in enumerate(rs_r) if i not in big]
    yrs = {}
    for k, x in zip(ks_w, rs_w):
        y = datetime.fromtimestamp((raw.lo + k * MIN) / 1000, tz=timezone.utc).year
        yrs.setdefault(y, []).append(x)
    return dict(n=n, m_raw=m_raw, t_raw=t_raw, med=med, m_w=m_w, t_w=t_w, z_w=z_w,
                up=100 * sum(1 for x in rs_r if x + raw.base[h] > 0) / n,
                loo=statistics.mean(rest) if len(rest) >= 5 else None,
                yr={y: (statistics.mean(v) if len(v) >= 8 else None, len(v)) for y, v in yrs.items()})


def biggest_moves(px, h, count=12):
    cand = []
    for k in range(260, px.n - 260, 5):
        v = px._raw(k, h)
        if v is not None:
            cand.append((abs(v), v, k))
    cand.sort(reverse=True)
    out = []
    for _, v, k in cand:
        if all(abs(k - k2) >= max(h, 240) for _, k2 in out):
            out.append((v, k))
        if len(out) >= count:
            break
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--prices", required=True)
    ap.add_argument("--cache", default="astro2_cache.pkl")
    ap.add_argument("--cache4", default="astro4_cache.pkl")
    ap.add_argument("--start"); ap.add_argument("--end")
    ap.add_argument("--point", type=float, default=0.001)
    ap.add_argument("--price-offset", type=float, default=0.0)
    ap.add_argument("--shifts", type=int, default=30)
    ap.add_argument("--wins", type=float, default=0.01, help="winsorise at this tail share (0.01 = 1st/99th percentile)")
    ap.add_argument("--min-run", type=int, default=5)
    ap.add_argument("--out", default="event_robust.csv")
    a = ap.parse_args()

    pr = B.load_prices(a.prices, a.price_offset)
    ts = sorted(pr)
    lo = max(ts[0], int(datetime.fromisoformat(a.start).replace(tzinfo=timezone.utc).timestamp() * 1000)) if a.start else ts[0]
    hi = min(ts[-1], int(datetime.fromisoformat(a.end).replace(tzinfo=timezone.utc).timestamp() * 1000)) if a.end else ts[-1]
    lo, hi = lo // DAY * DAY, (hi // DAY + 1) * DAY
    n = (hi - lo) // MIN
    A = T.build_astro(lo, hi, a.cache)
    A4 = S.build_astro4(lo, hi, a.cache4)
    o, h_, l_, c, ok = B.align_prices(pr, lo, n)
    raw = S.Px(c, ok, a.point, lo)
    win = S.Px(c, ok, a.point, lo, wins=a.wins)
    shifts = [w * 7 * 1440 for k in range(1, a.shifts // 2 + 2) for w in (k, -k)][:a.shifts]
    groups = S.build_groups(A, A4, a.min_run)
    t0 = time.time()
    tu = lambda k: datetime.fromtimestamp((lo + k * MIN) / 1000, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")

    # ---- 1. data check
    print("=== 1. DATA CHECK: how big are the moves, and when? (points; 1 point = 0.001) ===")
    print("typical move (standard deviation) by year:")
    print(f"{'year':>6s} {'30 min':>9s} {'240 min':>9s}")
    for y in sorted({datetime.fromtimestamp((lo + k * MIN) / 1000, tz=timezone.utc).year for k in range(0, n, 1440)}):
        row = []
        for h in (30, 240):
            xs = [raw._raw(k, h) for k in range(260, n - 260, 25)
                  if datetime.fromtimestamp((lo + k * MIN) / 1000, tz=timezone.utc).year == y]
            xs = [x for x in xs if x is not None]
            row.append(statistics.pstdev(xs) if len(xs) > 10 else float("nan"))
        print(f"{y:>6d} {row[0]:9.0f} {row[1]:9.0f}")
    for h in (30, 240):
        print(f"largest {h}-minute moves (start time UTC, change in points):")
        for v, k in biggest_moves(raw, h):
            print(f"    {tu(k)}   {v:+8.0f}")
    print(f"winsorising caps every change at the {a.wins*100:g}% and {100-a.wins*100:g}% percentiles; caps in points: "
          + ", ".join(f"{h}m [{win.cap[h][0]:+.0f}, {win.cap[h][1]:+.0f}]" for h in S.HORIZONS))

    # ---- 2. every cell
    cells = []
    for sec, label, ev, hz in groups:
        for h in hz:
            r = rob(raw, win, ev, h, shifts)
            if r:
                cells.append((label, h, r))
    allcells = cells
    cells = [c_ for c_ in allcells if c_[2]["n"] >= 20]   # cells with fewer than 20 events are shown in the CSV but not scored
    zs = [r["z_w"] for _, _, r in cells]
    zsd = statistics.pstdev(zs)
    for _, _, r in allcells:
        r["z_cal"] = r["z_w"] / max(1.0, zsd)
    N = len(cells)
    tcrit = NormalDist().inv_cdf(1 - 0.025 / N)

    # ---- 3. candidates
    print(f"\n=== 2. THE CELLS WE DISCUSSED (points; winsorised means; positive = price rose) ===")
    print(f"{'cell':54s}{'min':>5s}{'n':>6s} {'raw mean (t)':>15s} {'median':>8s} {'winsor (t)':>14s} {'z cal':>6s}  {'2024':>7s} {'2025':>7s} {'2026':>7s}  {'drop 5 biggest':>14s}")
    by = {(l, h): r for l, h, r in allcells}
    for label, h in CANDIDATES:
        r = by.get((label, h))
        if not r:
            continue
        yr = lambda y: ("%+7.0f" % r["yr"][y][0]) if y in r["yr"] and r["yr"][y][0] is not None else "      -"
        loo = "      -" if r["loo"] is None else "%+7.0f" % r["loo"]
        print(f"{label[:54]:54s}{h:>5d}{r['n']:6d} {r['m_raw']:+8.1f} ({r['t_raw']:+4.1f}) {r['med']:+8.1f} {r['m_w']:+8.1f} ({r['t_w']:+4.1f}) {r['z_cal']:+6.1f}  {yr(2024)} {yr(2025)} {yr(2026)}  {loo:>14s}")

    # ---- 4. strict rule
    print(f"\n=== 3. STRICT RULE over the {N} cells with 20+ events ===")
    print(f"calibration: the z scores of all cells have a spread of {zsd:.2f} (1.0 = nothing going on); z cal = z divided by that. "
          f"Winsorised |t| limit for {N} cells: {tcrit:.1f}.")
    print(f"cells with winsorised |t| above 2: {sum(1 for _,_,r in cells if abs(r['t_w'])>2)} ({100*sum(1 for _,_,r in cells if abs(r['t_w'])>2)/N:.0f}% against about 5% by chance); "
          f"above 2.5: {sum(1 for _,_,r in cells if abs(r['t_w'])>2.5)}; raw |t| above 2: {sum(1 for _,_,r in cells if abs(r['t_raw'])>2)}")

    def passes(r):
        if r["n"] < 30 or abs(r["t_w"]) < tcrit:
            return False
        sgn = 1 if r["m_w"] > 0 else -1
        if (r["med"] > 0) != (sgn > 0):
            return False
        ys = [v for v, _ in r["yr"].values() if v is not None]
        return len(ys) >= 2 and all((v > 0) == (sgn > 0) for v in ys)

    good = [(l, h, r) for l, h, r in cells if passes(r)]
    print("cells that pass:", "none" if not good else "")
    for l, h, r in good:
        print(f"    {l}, {h} min: n={r['n']} winsor {r['m_w']:+.1f} (t {r['t_w']:+.1f})")
    print("ten largest winsorised |t| (near misses and chance):")
    for l, h, r in sorted(cells, key=lambda x: -abs(x[2]["t_w"]))[:10]:
        ys = " ".join(f"{y}:{('%+.0f' % v) if v is not None else '-'}" for y, (v, _) in sorted(r["yr"].items()))
        print(f"    {l[:50]:50s} {h:>5d}m n={r['n']:5d} winsor={r['m_w']:+7.1f} t={r['t_w']:+5.1f} median={r['med']:+7.1f}  {ys}")

    with open(a.out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["event", "horizon_min", "n", "raw_mean", "raw_t", "median", "winsor_mean", "winsor_t", "z_calibrated", "drop5_mean", "up_pct"])
        for l, h, r in allcells:
            w.writerow([l, h, r["n"], round(r["m_raw"], 1), round(r["t_raw"], 2), round(r["med"], 1), round(r["m_w"], 1),
                        round(r["t_w"], 2), round(r["z_cal"], 2), "" if r["loo"] is None else round(r["loo"], 1), round(r["up"], 1)])
    print(f"\nall cells written to {a.out}   (took {time.time()-t0:.0f}s)")


if __name__ == "__main__":
    main()
