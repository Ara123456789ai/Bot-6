#!/usr/bin/env python3
"""
Event study (stage 5): what does Brent do after a signal? No stops, no targets, no spread: just the average price change in points
(positive = price rose) at 5, 30, 60 and 240 minutes after each event, compared with random timing.

Events
  A. Pluto and Saturn aspects to the Ascendant (3 degree orb), onset of each aspect window (windows under 5 minutes skipped):
       all trigger angles, + actors strip amber, + Sentiment Index S below -0.15, and each angle on its own (30/45/60/90/120/135/150).
  B. Transiting Moon to transit Saturn and to transit Pluto (3 degree orb), every angle the app knows from the conjunction through 180
       (0, 30, 45, 60, 72, 90, 120, 135, 144, 150, 180), each one at two moments:
       onset = the minute the Moon enters the orb; exact = the minute of the smallest orb in that pass.
       Grouped rows: all angles, hard angles (0/45/90/135/150/180), soft angles (30/60/72/120/144).
       For "exact" events the move INTO the aspect (240 minutes before to the event) is shown as well.
Statistics
  mean   = average price change in points minus the average change over all minutes (the market's drift)
  (t)    = mean / standard error, events thinned so that their windows never overlap
  z      = how far the real mean sits from the same events moved by whole weeks (random timing, same weekdays and hours)
  up%    = share of events with a rise
Run: python3 event_study.py --prices download/brentcmdusd-m1-bid-2024-01-01-2026-11-10.csv > event_report.txt
"""
import argparse, csv, os, pickle, re, statistics, sys, time
from datetime import datetime, timezone
from multiprocessing import Pool
from itertools import accumulate

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import resonant_engine as E
import backtest as B
import entry_tests as T

MIN, DAY, SELL = B.MIN, B.DAY, T.SELL
ANG11 = E.ANGLES                       # 0 30 45 60 72 90 120 135 144 150 180
HARD = {0, 45, 90, 135, 150, 180}
HORIZONS = [5, 30, 60, 240]
NONE = 255
FIELDS4 = ["sat_a", "sat_o", "plu_a", "plu_o"]


# ------------------------------------------------------------------ Moon to Saturn / Pluto, per minute (computed every 5 minutes)
def _chunk4(args):
    a, b = args
    cols = {k: bytearray() for k in FIELDS4}
    t = a
    while t < b:
        pos = E.planetary_positions(t)
        m = pos[E.IDX["Moon"]]
        for name, ka, ko in (("Saturn", "sat_a", "sat_o"), ("Pluto", "plu_a", "plu_o")):
            s = E.sep(m, pos[E.IDX[name]])
            best, ang = 99.0, NONE
            for i, A in enumerate(ANG11):
                dd = abs(s - A)
                if dd <= 3.0 and dd < best:
                    best, ang = dd, i
            cols[ka] += bytes([ang]) * 5
            cols[ko] += bytes([min(255, int(round(best * 40)) if ang != NONE else 255)]) * 5
        t += 5 * MIN
    return [bytes(cols[k]) for k in FIELDS4]


def build_astro4(start_ms, end_ms, cache):
    if cache and os.path.exists(cache):
        with open(cache, "rb") as f:
            d = pickle.load(f)
        if d.get("v") == 1 and d["start"] == start_ms and d["end"] == end_ms:
            print(f"Moon-aspect flags loaded from {cache}", file=sys.stderr)
            return d
    jobs = [(t, min(t + 2 * DAY, end_ms)) for t in range(start_ms, end_ms, 2 * DAY)]
    t0 = time.time()
    with Pool() as p:
        parts = p.map(_chunk4, jobs)
    d = {"v": 1, "start": start_ms, "end": end_ms}
    for i, k in enumerate(FIELDS4):
        d[k] = b"".join(pt[i] for pt in parts)
    print(f"Moon-aspect flags built in {time.time()-t0:.0f}s", file=sys.stderr)
    if cache:
        with open(cache, "wb") as f:
            pickle.dump(d, f)
    return d


# ------------------------------------------------------------------ events from masks
def run_spans(mask_bytes, min_run=1):
    return [(m.start(), m.end()) for m in re.finditer(rb"\x01+", mask_bytes) if m.end() - m.start() >= min_run]


def flag(a_bytes, idxs):
    tbl = bytes(1 if v in idxs else 0 for v in range(256))
    return a_bytes.translate(tbl)


def band(x_bytes, y_bytes):
    n = len(x_bytes)
    return (int.from_bytes(x_bytes, "big") & int.from_bytes(y_bytes, "big")).to_bytes(n, "big")


def onset_events(mask, min_run=5):
    return [a for a, b in run_spans(mask, min_run)]


def exact_events(ang_bytes, orb_bytes, angle_idxs, min_run=1):
    """One event per Moon pass: the minute of the smallest orb (first such minute)."""
    ev = []
    for i in angle_idxs:
        for a, b in run_spans(flag(ang_bytes, {i}), min_run):
            seg = orb_bytes[a:b]
            ev.append(a + seg.index(min(seg)))
    return sorted(ev)


# ------------------------------------------------------------------ price changes
class Px:
    def __init__(self, c, ok, point, lo, wins=None):
        """wins: e.g. 0.01 caps every price change at the 1st and 99th percentile of all changes over the same horizon."""
        self.c, self.ok, self.pt, self.lo = c, ok, point, lo
        self.n = len(c)
        self.pre = [0] + list(accumulate(1 if v == 1 else 0 for v in ok))   # only real bars (ok == 1); 2 = forward-filled, 0 = none
        self.cap, self.base, self.bmed = {}, {}, {}
        for h in HORIZONS + [-240]:
            xs = sorted(x for x in (self._raw(k, h) for k in range(260, self.n - 260, 5)) if x is not None)
            self.bmed[h] = xs[len(xs) // 2]
            if wins:
                self.cap[h] = (xs[int(wins * (len(xs) - 1))], xs[int((1 - wins) * (len(xs) - 1))])
            self.base[h] = self.mean_all(h)

    def _raw(self, k, h):
        n, ok, pre = self.n, self.ok, self.pre
        if h > 0:
            j = k + h
            if j >= n or ok[k] != 1 or ok[j] != 1 or pre[j + 1] - pre[k + 1] < 0.9 * h:
                return None
            return (self.c[j] - self.c[k]) / self.pt
        h = -h
        j = k - h
        if j < 0 or ok[k] != 1 or ok[j] != 1 or pre[k + 1] - pre[j + 1] < 0.9 * h:
            return None
        return (self.c[k] - self.c[j]) / self.pt

    def r(self, k, h):
        """Price change in points over h minutes after k (h > 0) or into k from -h minutes before (h < 0). None if the market was shut."""
        v = self._raw(k, h)
        if v is None or h not in self.cap:
            return v
        lo, hi = self.cap[h]
        return min(hi, max(lo, v))

    def mean_all(self, h):
        xs = [self.r(k, h) for k in range(260, self.n - 260, 5)]
        xs = [x for x in xs if x is not None]
        return statistics.mean(xs)


def thin(events, gap):
    out, last = [], -10 ** 12
    for k in events:
        if k - last >= gap:
            out.append(k)
            last = k
    return out


def sample(px, events, h):
    ev = thin(sorted(events), abs(h))
    rs, ks = [], []
    for k in ev:
        v = px.r(k, h)
        if v is not None:
            rs.append(v - px.base[h])
            ks.append(k)
    return ks, rs


def measure(px, events, h):
    ks, rs = sample(px, events, h)
    n = len(rs)
    if n < 5:
        return None
    mean = statistics.mean(rs)
    sd = statistics.pstdev(rs)
    t = mean / (sd / n ** 0.5) if sd > 0 else 0.0
    up = 100 * sum(1 for x in rs if x + px.base[h] > 0) / n
    yr = [datetime.fromtimestamp((px.lo + k * MIN) / 1000, tz=timezone.utc).year for k in ks]
    a = [x for x, y in zip(rs, yr) if y <= 2025]
    b = [x for x, y in zip(rs, yr) if y >= 2026]
    return dict(n=n, mean=mean, t=t, up=up, m_ins=statistics.mean(a) if len(a) >= 8 else None,
                m_out=statistics.mean(b) if len(b) >= 8 else None)


def null_stats(px, events, h, shifts):
    vals = []
    for r in shifts:
        ev = [(k + r) % px.n for k in events]
        ks, rs = sample(px, ev, h)
        if len(rs) >= 5:
            vals.append(statistics.mean(rs))
    if len(vals) < 5:
        return None, None
    return statistics.mean(vals), statistics.pstdev(vals)


def build_groups(A, A4, min_run=5):
    """(section, label, events, horizons) for every event family."""
    groups = []    # (section, label, events, horizons)
    amber = {"Pluto": A["pamb"], "Saturn": A["samb"]}
    ang = {"Pluto": A["pa"], "Saturn": A["sa"]}
    for planet in ("Saturn", "Pluto"):
        anyang = flag(ang[planet], set(range(len(SELL))))
        groups.append(("A", f"{planet} Ascendant aspect, any angle", onset_events(anyang, min_run), HORIZONS))
        groups.append(("A", f"{planet} aspect + actors strip amber", onset_events(band(anyang, amber[planet]), min_run), HORIZONS))
        groups.append(("A", f"{planet} aspect + amber + S below -0.15", onset_events(band(band(anyang, amber[planet]), A["sred"]), min_run), HORIZONS))
        for i, angle in enumerate(SELL):
            groups.append(("A", f"{planet} Ascendant aspect at {angle} deg", onset_events(flag(ang[planet], {i}), min_run), HORIZONS))
    for planet, ka, ko in (("Saturn", "sat_a", "sat_o"), ("Pluto", "plu_a", "plu_o")):
        for mode in ("onset", "exact"):
            hz = HORIZONS + ([-240] if mode == "exact" else [])
            sets = {"all angles": set(range(len(ANG11))),
                    "hard angles (0/45/90/135/150/180)": {i for i, x in enumerate(ANG11) if x in HARD},
                    "soft angles (30/60/72/120/144)": {i for i, x in enumerate(ANG11) if x not in HARD}}
            for name, idxs in sets.items():
                ev = exact_events(A4[ka], A4[ko], idxs) if mode == "exact" else sorted(a_ for i in idxs for a_, b_ in run_spans(flag(A4[ka], {i})))
                groups.append(("B", f"Moon-{planet} {name}, {mode}", ev, hz))
            for i, x in enumerate(ANG11):
                ev = exact_events(A4[ka], A4[ko], {i}) if mode == "exact" else [a_ for a_, b_ in run_spans(flag(A4[ka], {i}))]
                groups.append(("B", f"Moon-{planet} at {x} deg, {mode}", ev, hz))
    return groups


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--prices", required=True)
    ap.add_argument("--cache", default="astro2_cache.pkl")
    ap.add_argument("--cache4", default="astro4_cache.pkl")
    ap.add_argument("--start"); ap.add_argument("--end")
    ap.add_argument("--point", type=float, default=0.001)
    ap.add_argument("--price-offset", type=float, default=0.0)
    ap.add_argument("--shifts", type=int, default=30, help="whole-week shifts used for random timing")
    ap.add_argument("--min-run", type=int, default=5)
    ap.add_argument("--out", default="event_study.csv")
    a = ap.parse_args()

    pr = B.load_prices(a.prices, a.price_offset)
    ts = sorted(pr)
    lo = max(ts[0], int(datetime.fromisoformat(a.start).replace(tzinfo=timezone.utc).timestamp() * 1000)) if a.start else ts[0]
    hi = min(ts[-1], int(datetime.fromisoformat(a.end).replace(tzinfo=timezone.utc).timestamp() * 1000)) if a.end else ts[-1]
    lo, hi = lo // DAY * DAY, (hi // DAY + 1) * DAY
    n = (hi - lo) // MIN
    print(f"prices: {len(pr)} minute bars; testing {n} minutes", file=sys.stderr)
    A = T.build_astro(lo, hi, a.cache)
    A4 = build_astro4(lo, hi, a.cache4)
    o, h_, l_, c, ok = B.align_prices(pr, lo, n)
    px = Px(c, ok, a.point, lo)
    shifts = [w * 7 * 1440 for k in range(1, a.shifts // 2 + 2) for w in (k, -k)][:a.shifts]
    t0 = time.time()

    groups = build_groups(A, A4, a.min_run)

    # ---- measure
    rows, tests, out_groups = [], [], []
    for sec, label, ev, hz in groups:
        per = {}
        for hh in hz:
            m = measure(px, ev, hh)
            if m is None:
                continue
            mu, sd = null_stats(px, ev, hh, shifts)
            m["z"] = (m["mean"] - mu) / sd if sd else 0.0
            per[hh] = m
            tests.append((label, hh, m))
            rows.append((sec, label, hh, m["n"], round(m["mean"], 1), round(m["t"], 2), round(m["z"], 2), round(m["up"], 1)))
        out_groups.append((sec, label, len(ev), per, hz))
    groups = out_groups

    def line(label, n_ev, per, hz):
        s = f"{label:50s}{n_ev:5d} "
        for hh in hz:
            m = per.get(hh)
            s += "  " + (f"{m['mean']:+6.1f} ({m['t']:+5.1f})" if m else "      -       ")
        return s

    print("Average price change in points after each event (t in brackets; positive = price rose). Drift removed.")
    print("Baseline drift of the market over the same horizons: " + ", ".join(f"{h}m {px.base[h]:+.1f}" for h in HORIZONS))
    print("Typical size of a move: 5m about %.0f, 30m about %.0f, 60m about %.0f, 240m about %.0f points (standard deviation)."
          % tuple(statistics.pstdev([x for x in (px.r(k, h) for k in range(260, n - 260, 25)) if x is not None]) for h in HORIZONS))

    head_a = f"{'':50s}{'events':>5s}   " + "".join(f"{str(h)+' min':^18s}" for h in HORIZONS)
    print("\n=== 1. PLUTO AND SATURN ASPECTS TO THE ASCENDANT (event = the aspect window opens) ===")
    print(head_a)
    for g in groups:
        if g[0] == "A":
            print(line(g[1], g[2], g[3], HORIZONS))

    head_b = f"{'':50s}{'events':>5s}   " + "".join(f"{(str(h)+' min') if h > 0 else 'into event':^18s}" for h in [-240] + HORIZONS)
    for planet in ("Saturn", "Pluto"):
        print(f"\n=== {'2' if planet=='Saturn' else '3'}. MOON-{planet.upper()} ASPECTS, 3 DEGREE ORB: price change after the Moon enters the orb (onset) and after the exact moment ===")
        print("(each angle has only about 30-45 passes in three years, so single angles are weak evidence; read the grouped rows first)")
        print(head_b)
        for g in groups:
            if g[0] == "B" and f"Moon-{planet}" in g[1]:
                per, hz = g[3], [-240] + HORIZONS
                s = f"{g[1]:50s}{g[2]:5d} "
                for hh in hz:
                    m = per.get(hh)
                    s += "  " + (f"{m['mean']:+6.1f} ({m['t']:+5.1f})" if m else "      -       ")
                print(s)

    # ---- trust
    N = len(tests)
    from statistics import NormalDist
    zc = NormalDist().inv_cdf(1 - 0.025 / max(1, N))
    zs = [m["z"] for _, _, m in tests]
    print(f"\n=== 4. HOW MUCH TO TRUST ANY SINGLE CELL ===")
    print(f"{N} cells were measured. By chance alone the biggest |z| among {N} cells is expected near {NormalDist().inv_cdf(1 - 0.5 / N):.1f}; "
          f"a cell counts only if |z| is above {zc:.1f}, it has 30+ events, and it points the same way in 2024-25 and 2026.")
    print(f"calibration: standard deviation of z over all cells = {statistics.pstdev(zs):.2f} (about 1.0 if nothing is going on); "
          f"cells with |z| above 2: {sum(1 for z in zs if abs(z) > 2)} ({100*sum(1 for z in zs if abs(z) > 2)/N:.0f}% against about 5% by chance)")
    good = [(lab, hh, m) for lab, hh, m in tests if abs(m["z"]) >= zc and m["n"] >= 30 and m["m_ins"] is not None and m["m_out"] is not None
            and (m["m_ins"] > 0) == (m["m_out"] > 0) == (m["mean"] > 0)]
    print("cells that pass:", "none" if not good else "")
    for lab, hh, m in good:
        print(f"    {lab}, {hh} min: n={m['n']} mean={m['mean']:+.1f} (t {m['t']:+.1f}, z {m['z']:+.1f})")
    print("ten largest |z| (for curiosity; most will be chance):")
    for lab, hh, m in sorted(tests, key=lambda x: -abs(x[2]["z"]))[:10]:
        mi = "-" if m["m_ins"] is None else f"{m['m_ins']:+.1f}"
        mo = "-" if m["m_out"] is None else f"{m['m_out']:+.1f}"
        print(f"    {lab[:46]:46s} {hh:>5d}m n={m['n']:4d} mean={m['mean']:+7.1f} t={m['t']:+5.1f} z={m['z']:+5.1f} up={m['up']:4.0f}%  2024-25 {mi}  2026 {mo}")

    with open(a.out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["section", "event", "horizon_min", "n", "mean_pts_minus_drift", "t", "z_vs_random_weeks", "up_pct"])
        w.writerows(rows)
    print(f"\nall cells written to {a.out}   (took {time.time()-t0:.0f}s)")


if __name__ == "__main__":
    main()
