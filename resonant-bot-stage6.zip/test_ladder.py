"""Tests for the stop / breakeven / trail logic in ladder_test.py. Run: python3 test_ladder.py"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ladder_test as L

N = 60
P = dict(spread=0.021, point=0.001, sl=300, be=300, min_run=5)


def make(patch=None, emaH=101.0):
    o = [100.0] * N; h = [100.0] * N; l = [100.0] * N; c = [100.0] * N
    for k, v in (patch or {}).items():
        o[k], h[k], l[k], c[k] = v
    X = type("X", (), {})()
    X.o, X.h, X.l, X.c, X.p, X.flat = o, h, l, c, P, bytes(N)
    X.emaH = [emaH] * N if not isinstance(emaH, list) else emaH
    return X


def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (" " + extra if extra else ""))
    if not cond:
        sys.exit(1)


act = bytes([1]) * N


def flat_bars(a, b, v):
    return {k: (v, v, v, v) for k in range(a, b)}

E0 = 100.0

# 1. initial stop 300 points above the sell price
X = make({12: (100.0, 100.4, 100.0, 100.3)})
r = L.manage_trail(10, E0, act, X, "be", False)
check("initial stop at +300 points", r[1] == "SL" and r[0] == 12 and abs(r[2] + 0.3) < 1e-9, str(r))

# 2. price falls 300+ (ask low <= entry - 0.3), then rallies back to the entry: breakeven exit, zero points
X = make({12: (99.9, 99.9, 99.6, 99.62), **flat_bars(13, 14, 99.7), 14: (99.8, 100.2, 99.8, 100.1)})
r = L.manage_trail(10, E0, act, X, "be", False)
check("breakeven after +300 then exit at entry", r[1] == "BE" and r[0] == 14 and abs(r[2]) < 1e-9, str(r))

# 3. trail follows the EMA of highs after breakeven (only moves down)
ema = [101.0] * N
for k in range(12, N):
    ema[k] = 99.9 if k >= 13 else 101.0
X = make({12: (99.9, 99.9, 99.6, 99.62), **flat_bars(13, 20, 99.7), 20: (99.7, 99.95, 99.7, 99.9)}, emaH=ema)
r = L.manage_trail(10, E0, act, X, "be", False)
check("trail exit at the EMA of highs, in profit", r[1] == "TRAIL" and r[0] == 20 and abs(r[2] - 0.1) < 1e-9, str(r))

# 4. before breakeven the trail is off by default, on from entry with --trail-from entry
ema = [99.99] * N
X = make({12: (99.95, 100.0, 99.95, 99.96), **flat_bars(13, 30, 99.9)}, emaH=ema)
r1 = L.manage_trail(10, E0, act, X, "be", False)
r2 = L.manage_trail(10, E0, act, X, "entry", False)
check("no trail before breakeven (default)", r1[0] != 11 and r1[1] != "TRAIL", str(r1))
check("trail from entry exits once the ask reaches the EMA of highs (at the open ask here)", r2[1] == "TRAIL" and r2[0] == 11 and abs(r2[2] + 0.021) < 1e-9, str(r2))

# 5. the trail never moves up
ema = [101.0] * N
for k in range(12, N):
    ema[k] = 99.9 if k < 16 else 100.05
X = make({12: (99.9, 99.9, 99.6, 99.62), **flat_bars(13, 25, 99.7), 25: (99.9, 99.98, 99.9, 99.95)}, emaH=ema)
r = L.manage_trail(10, E0, act, X, "be", False)
check("a rising EMA does not loosen the stop", r[1] == "TRAIL" and r[0] == 25, str(r))

# 6. exit at the aspect end when asked
act2 = bytes(1 if k < 30 else 0 for k in range(N))
X = make(flat_bars(11, 60, 99.9))
r = L.manage_trail(10, E0, act2, X, "be", True)
check("optional exit when the aspect ends", r[1] == "ASPECT" and r[0] == 30, str(r))
print("all ladder tests passed")
