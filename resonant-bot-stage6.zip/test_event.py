"""Tests for event_study.py helpers. Run: python3 test_event.py"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import event_study as S

def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (" " + extra if extra else ""))
    if not cond:
        sys.exit(1)

# rising price: +0.001 per minute (1 point per minute); drift is 1 point per minute so excess is ~0
N = 3000
c = [100 + 0.001 * k for k in range(N)]
ok = bytearray([1] * N)
px = S.Px(c, ok, 0.001, 0)
check("forward change of 30 minutes is 30 points", abs(px.r(500, 30) - 30) < 1e-6)
check("change into an event over 240 minutes is 240 points", abs(px.r(1000, -240) - 240) < 1e-6)
check("drift removed: a steady trend leaves nothing", abs(S.measure(px, list(range(300, 2000, 50)), 30)["mean"]) < 1e-6)
# closed market inside the window -> no value
ok2 = bytearray(ok)
for k in range(520, 560):
    ok2[k] = 0
px2 = S.Px(c, ok2, 0.001, 0)
check("a window that crosses a shut market is skipped", px2.r(500, 60) is None)
# forward-filled minutes (ok == 2, market shut) are not valid: no event on them, and no window that runs across them
ok3 = bytearray(ok)
for k in range(1000, 1500):
    ok3[k] = 2
px3 = S.Px(c, ok3, 0.001, 0)
check("an event inside a shut market is skipped", px3.r(1200, 30) is None)
check("a window that ends in a shut market is skipped", px3.r(990, 30) is None)
check("a window across a gap of forward-filled bars is skipped", px3.r(900, 240) is None)
check("windows on real bars still work", px3.r(1600, 30) is not None)
# thinning keeps events at least h minutes apart
check("overlapping events are thinned", S.thin([0, 10, 20, 100, 105], 50) == [0, 100])
# exact event = minute of smallest orb in each pass
ang = bytes([255] * 5 + [3] * 10 + [255] * 5 + [3] * 10)
orb = bytes([255] * 5 + [90, 80, 70, 60, 40, 20, 30, 50, 70, 90] + [255] * 5 + [100, 90, 60, 50, 40, 30, 20, 10, 20, 30])
check("exact events sit at the smallest orb of each pass", S.exact_events(ang, orb, {3}) == [10, 27], str(S.exact_events(ang, orb, {3})))
check("onset events are the start of each pass", [a for a, b in S.run_spans(S.flag(ang, {3}))] == [5, 20])
print("all event tests passed")
